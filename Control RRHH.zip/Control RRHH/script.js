// Credenciales válidas
const CREDENCIALES = {
    usuario: "admin",
    contraseña: "Sabtra2024" // Cambia esta contraseña
};

// Datos y configuración inicial
let empleados = JSON.parse(localStorage.getItem('empleados')) || [];
let empleadoEditando = null;
const meses = [
    { nombre: "Enero", numero: 0 },
    { nombre: "Febrero", numero: 1 },
    { nombre: "Marzo", numero: 2 },
    { nombre: "Abril", numero: 3 },
    { nombre: "Mayo", numero: 4 },
    { nombre: "Junio", numero: 5 },
    { nombre: "Julio", numero: 6 },
    { nombre: "Agosto", numero: 7 },
    { nombre: "Septiembre", numero: 8 },
    { nombre: "Octubre", numero: 9 },
    { nombre: "Noviembre", numero: 10 },
    { nombre: "Diciembre", numero: 11 }
];

// Elementos del DOM
const loginScreen = document.getElementById('login-screen');
const appContainer = document.getElementById('app-container');
const loginForm = document.getElementById('loginForm');
const logoutBtn = document.getElementById('btn-logout');
const empleadoForm = document.getElementById('empleadoForm');
const btnGuardar = document.getElementById('btnGuardar');
const btnCancelar = document.getElementById('btnCancelar');
const empleadoIdInput = document.getElementById('empleadoId');
const confirmModal = document.getElementById('confirmModal');
const modalConfirm = document.getElementById('modalConfirm');
const modalCancel = document.getElementById('modalCancel');

// Inicialización al cargar la página
document.addEventListener('DOMContentLoaded', function() {
    // Verificar si ya está autenticado
    const autenticado = localStorage.getItem('autenticado') === 'true';
    
    if (autenticado) {
        loginScreen.classList.add('hidden');
        appContainer.classList.remove('hidden');
        inicializarAplicacion();
    } else {
        loginScreen.classList.remove('hidden');
        appContainer.classList.add('hidden');
    }
    
    // Evento del formulario de login
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        const username = document.getElementById('username').value.trim();
        const password = document.getElementById('password').value;
        
        if (username === CREDENCIALES.usuario && password === CREDENCIALES.contraseña) {
            localStorage.setItem('autenticado', 'true');
            loginScreen.classList.add('hidden');
            appContainer.classList.remove('hidden');
            inicializarAplicacion();
        } else {
            mostrarError('loginError', 'Usuario o contraseña incorrectos');
        }
    });
    
    // Evento de logout
    logoutBtn.addEventListener('click', function() {
        localStorage.removeItem('autenticado');
        location.reload();
    });
});

function inicializarAplicacion() {
    // Configurar eventos de pestañas
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.addEventListener('click', function() {
            const tabId = this.getAttribute('data-tab');
            abrirPestana(tabId);
        });
    });
    
    // Evento del formulario de empleado
    empleadoForm.addEventListener('submit', guardarEmpleado);
    
    // Evento del botón cancelar
    btnCancelar.addEventListener('click', cancelarEdicion);
    
    // Eventos del modal
    modalCancel.addEventListener('click', cerrarModal);
    
    // Evento del filtro
    document.getElementById('btnFiltrar').addEventListener('click', filtrarPorAnio);
    
    // Generar botones de meses para vacaciones
    generarMesesVacaciones();
    
    // Cargar datos iniciales
    if (empleados.length > 0) {
        filtrarPorAnio();
        mostrarEmpleadosVacaciones(0); // Mostrar enero por defecto
    } else {
        mostrarEstadoVacio();
    }
}

// Funciones de pestañas
function abrirPestana(tabId) {
    // Ocultar todos los contenidos
    document.querySelectorAll('.tab-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Desactivar todos los botones
    document.querySelectorAll('.nav-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Activar la pestaña seleccionada
    document.getElementById(tabId).classList.add('active');
    document.querySelector(`.nav-btn[data-tab="${tabId}"]`).classList.add('active');
    
    // Cargar datos si es necesario
    if (tabId === 'listado') {
        filtrarPorAnio();
    } else if (tabId === 'vacaciones') {
        if (empleados.length === 0) {
            mostrarEstadoVacio();
        }
    }
}

// Funciones para empleados
function guardarEmpleado(e) {
    e.preventDefault();
    
    // Validar formulario
    if (!validarFormulario()) return;
    
    // Obtener valores
    const id = empleadoIdInput.value || Date.now().toString();
    const nombre = document.getElementById('nombre').value.trim();
    const cedula = document.getElementById('cedula').value.trim();
    const cargo = document.getElementById('cargo').value.trim();
    const fechaIngreso = document.getElementById('fechaIngreso').value;
    
    // Verificar cédula única (excepto si estamos editando el mismo empleado)
    const cedulaExistente = empleados.find(emp => emp.cedula === cedula && emp.id !== id);
    if (cedulaExistente) {
        mostrarError('cedulaError', 'Esta cédula ya está registrada');
        return;
    }
    
    // Crear/actualizar empleado
    const empleado = {
        id,
        nombre,
        cedula,
        cargo,
        fechaIngreso
    };
    
    if (empleadoEditando) {
        // Actualizar empleado existente
        const index = empleados.findIndex(emp => emp.id === empleadoEditando.id);
        empleados[index] = empleado;
        mostrarNotificacion('Empleado actualizado con éxito', 'success');
    } else {
        // Agregar nuevo empleado
        empleados.push(empleado);
        mostrarNotificacion('Empleado registrado con éxito', 'success');
    }
    
    // Guardar y resetear
    localStorage.setItem('empleados', JSON.stringify(empleados));
    resetearFormulario();
    
    // Actualizar vistas
    filtrarPorAnio();
    generarMesesVacaciones();
    
    // Mostrar en vacaciones si corresponde
    if (document.getElementById('vacaciones').classList.contains('active')) {
        const mesActual = document.querySelector('.month-btn.active')?.dataset.mes || 0;
        mostrarEmpleadosVacaciones(parseInt(mesActual));
    }
}

function editarEmpleado(id) {
    empleadoEditando = empleados.find(emp => emp.id === id);
    if (!empleadoEditando) return;
    
    // Llenar formulario
    document.getElementById('nombre').value = empleadoEditando.nombre;
    document.getElementById('cedula').value = empleadoEditando.cedula;
    document.getElementById('cargo').value = empleadoEditando.cargo;
    document.getElementById('fechaIngreso').value = empleadoEditando.fechaIngreso;
    empleadoIdInput.value = empleadoEditando.id;
    
    // Cambiar texto del botón
    btnGuardar.innerHTML = '<i class="fas fa-save"></i> Actualizar Empleado';
    
    // Mostrar botón cancelar
    btnCancelar.classList.remove('hidden');
    
    // Ir a pestaña de registro
    abrirPestana('registro');
}

function eliminarEmpleado(id) {
    abrirModal(
        'Eliminar Empleado',
        '¿Estás seguro que deseas eliminar este empleado? Esta acción no se puede deshacer.',
        () => {
            empleados = empleados.filter(emp => emp.id !== id);
            localStorage.setItem('empleados', JSON.stringify(empleados));
            
            mostrarNotificacion('Empleado eliminado con éxito', 'success');
            
            // Actualizar vistas
            filtrarPorAnio();
            generarMesesVacaciones();
            
            // Mostrar en vacaciones si corresponde
            if (document.getElementById('vacaciones').classList.contains('active')) {
                const mesActual = document.querySelector('.month-btn.active')?.dataset.mes || 0;
                mostrarEmpleadosVacaciones(parseInt(mesActual));
            }
            
            cerrarModal();
        }
    );
}

function cancelarEdicion() {
    resetearFormulario();
}

function resetearFormulario() {
    empleadoForm.reset();
    empleadoIdInput.value = '';
    empleadoEditando = null;
    btnGuardar.innerHTML = '<i class="fas fa-save"></i> Guardar Empleado';
    btnCancelar.classList.add('hidden');
    
    // Limpiar errores
    document.querySelectorAll('.error-message').forEach(el => {
        el.textContent = '';
        el.style.display = 'none';
    });
}

// Validar formulario
function validarFormulario() {
    let valido = true;
    const nombre = document.getElementById('nombre').value.trim();
    const cedula = document.getElementById('cedula').value.trim();
    const cargo = document.getElementById('cargo').value.trim();
    const fechaIngreso = document.getElementById('fechaIngreso').value;
    
    // Validar nombre
    if (nombre === '') {
        mostrarError('nombreError', 'El nombre es requerido');
        valido = false;
    } else {
        ocultarError('nombreError');
    }
    
    // Validar cédula
    if (cedula === '') {
        mostrarError('cedulaError', 'La cédula es requerida');
        valido = false;
    } else if (!/^\d+$/.test(cedula)) {
        mostrarError('cedulaError', 'La cédula debe contener solo números');
        valido = false;
    } else {
        ocultarError('cedulaError');
    }
    
    // Validar cargo
    if (cargo === '') {
        mostrarError('cargoError', 'El cargo es requerido');
        valido = false;
    } else {
        ocultarError('cargoError');
    }
    
    // Validar fecha
    if (fechaIngreso === '') {
        mostrarError('fechaError', 'La fecha de ingreso es requerida');
        valido = false;
    } else {
        ocultarError('fechaError');
    }
    
    return valido;
}

// Funciones para listado
function filtrarPorAnio() {
    const anio = document.getElementById('filtroAnio').value;
    const contenedor = document.getElementById('contenedorMeses');
    contenedor.innerHTML = '';
    
    // Agrupar empleados por mes
    const empleadosPorMes = {};
    
    empleados.forEach(emp => {
        const fecha = new Date(emp.fechaIngreso);
        if (fecha.getFullYear() == anio) {
            const mes = fecha.getMonth();
            if (!empleadosPorMes[mes]) {
                empleadosPorMes[mes] = [];
            }
            empleadosPorMes[mes].push(emp);
        }
    });
    
    // Mostrar tarjetas por mes
    meses.forEach(mes => {
        const empleadosMes = empleadosPorMes[mes.numero] || [];
        
        const card = document.createElement('div');
        card.className = 'month-card';
        
        const header = document.createElement('div');
        header.className = 'month-header';
        header.innerHTML = `
            <span>${mes.nombre}</span>
            <span class="month-count">${empleadosMes.length}</span>
        `;
        
        const lista = document.createElement('div');
        lista.className = 'employee-list';
        
        if (empleadosMes.length > 0) {
            empleadosMes.forEach(emp => {
                const item = document.createElement('div');
                item.className = 'employee-item';
                item.innerHTML = `
                    <div>
                        <span class="employee-name">${emp.nombre}</span>
                        <div class="employee-position">${emp.cargo}</div>
                        <small>${new Date(emp.fechaIngreso).toLocaleDateString('es-ES')}</small>
                    </div>
                    <div class="employee-actions">
                        <button class="btn-edit" data-id="${emp.id}">
                            <i class="fas fa-edit"></i> Editar
                        </button>
                        <button class="btn-delete" data-id="${emp.id}">
                            <i class="fas fa-trash"></i> Eliminar
                        </button>
                    </div>
                `;
                lista.appendChild(item);
            });
        } else {
            lista.innerHTML = '<p class="empty-state">No hay empleados</p>';
        }
        
        card.appendChild(header);
        card.appendChild(lista);
        contenedor.appendChild(card);
    });
    
    // Configurar eventos de los botones
    document.querySelectorAll('.btn-edit').forEach(btn => {
        btn.addEventListener('click', function() {
            editarEmpleado(this.getAttribute('data-id'));
        });
    });
    
    document.querySelectorAll('.btn-delete').forEach(btn => {
        btn.addEventListener('click', function() {
            eliminarEmpleado(this.getAttribute('data-id'));
        });
    });
    
    // Mostrar mensaje si no hay datos
    if (contenedor.children.length === 0) {
        contenedor.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-users-slash"></i>
                <h3>No hay empleados registrados para este año</h3>
            </div>
        `;
    }
}

// Funciones para vacaciones
function generarMesesVacaciones() {
    const container = document.getElementById('mesesContainer');
    container.innerHTML = '';
    
    meses.forEach((mes, index) => {
        const empleadosMes = empleados.filter(emp => {
            const fecha = new Date(emp.fechaIngreso);
            return fecha.getMonth() === mes.numero;
        });
        
        const btn = document.createElement('button');
        btn.className = 'month-btn' + (index === 0 ? ' active' : '');
        btn.innerHTML = `
            ${mes.nombre}
            <small>(${empleadosMes.length})</small>
        `;
        btn.dataset.mes = mes.numero;
        
        btn.addEventListener('click', function() {
            document.querySelectorAll('.month-btn').forEach(b => b.classList.remove('active'));
            this.classList.add('active');
            mostrarEmpleadosVacaciones(parseInt(this.dataset.mes));
        });
        
        container.appendChild(btn);
    });
}

function mostrarEmpleadosVacaciones(mes) {
    const container = document.getElementById('empleadosVacaciones');
    container.innerHTML = '';
    
    const empleadosMes = empleados.filter(emp => {
        const fecha = new Date(emp.fechaIngreso);
        return fecha.getMonth() === mes;
    });
    
    if (empleadosMes.length === 0) {
        container.innerHTML = `
            <div class="empty-state">
                <i class="fas fa-user-times"></i>
                <h3>No hay empleados que ingresaron en ${meses[mes].nombre}</h3>
            </div>
        `;
        return;
    }
    
    empleadosMes.forEach(emp => {
        const fechaIngreso = new Date(emp.fechaIngreso);
        const hoy = new Date();
        
        // Calcular años de servicio
        const diffAnios = hoy.getFullYear() - fechaIngreso.getFullYear();
        const mesDiff = hoy.getMonth() - fechaIngreso.getMonth();
        const diaDiff = hoy.getDate() - fechaIngreso.getDate();
        const aniosCompletos = (mesDiff < 0 || (mesDiff === 0 && diaDiff < 0)) ? diffAnios - 1 : diffAnios;
        
        // Calcular fecha de aniversario este año
        const aniversarioEsteAnio = new Date(hoy.getFullYear(), fechaIngreso.getMonth(), fechaIngreso.getDate());
        
        // Calcular días hasta el próximo aniversario
        let diasHastaVacaciones = Math.floor((aniversarioEsteAnio - hoy) / (1000 * 60 * 60 * 24));
        
        // Si ya pasó el aniversario este año, calcular para el próximo año
        if (diasHastaVacaciones < 0) {
            const aniversarioProxAnio = new Date(hoy.getFullYear() + 1, fechaIngreso.getMonth(), fechaIngreso.getDate());
            diasHastaVacaciones = Math.floor((aniversarioProxAnio - hoy) / (1000 * 60 * 60 * 24));
        }
        
        // Crear elemento de vacaciones
        const item = document.createElement('div');
        item.className = 'vacation-item';
        
        if (aniosCompletos >= 1) {
            item.innerHTML = `
                <div class="vacation-info">
                    <h4>${emp.nombre}</h4>
                    <p>${emp.cargo} | Ingreso: ${fechaIngreso.toLocaleDateString('es-ES')}</p>
                    <div class="vacation-actions">
                        <button class="btn-edit" data-id="${emp.id}">
                            <i class="fas fa-edit"></i> Editar
                        </button>
                        <button class="btn-delete" data-id="${emp.id}">
                            <i class="fas fa-trash"></i> Eliminar
                        </button>
                    </div>
                </div>
                <div class="vacation-status status-available">
                    <i class="fas fa-check"></i> Disponible
                </div>
            `;
        } else {
            item.innerHTML = `
                <div class="vacation-info">
                    <h4>${emp.nombre}</h4>
                    <p>${emp.cargo} | Ingreso: ${fechaIngreso.toLocaleDateString('es-ES')}</p>
                    <div class="vacation-actions">
                        <button class="btn-edit" data-id="${emp.id}">
                            <i class="fas fa-edit"></i> Editar
                        </button>
                        <button class="btn-delete" data-id="${emp.id}">
                            <i class="fas fa-trash"></i> Eliminar
                        </button>
                    </div>
                </div>
                <div class="vacation-status status-pending">
                    ${diasHastaVacaciones} días
                </div>
            `;
        }
        
        container.appendChild(item);
    });
    
    // Configurar eventos de los botones
    document.querySelectorAll('.vacation-actions .btn-edit').forEach(btn => {
        btn.addEventListener('click', function() {
            editarEmpleado(this.getAttribute('data-id'));
        });
    });
    
    document.querySelectorAll('.vacation-actions .btn-delete').forEach(btn => {
        btn.addEventListener('click', function() {
            eliminarEmpleado(this.getAttribute('data-id'));
        });
    });
}

// Funciones auxiliares
function mostrarEstadoVacio() {
    const container = document.getElementById('empleadosVacaciones');
    container.innerHTML = `
        <div class="empty-state">
            <i class="fas fa-user-plus"></i>
            <h3>No hay empleados registrados</h3>
            <p>Registra empleados para ver su información de vacaciones</p>
        </div>
    `;
}

function mostrarError(elementId, mensaje) {
    const element = document.getElementById(elementId);
    element.textContent = mensaje;
    element.style.display = 'block';
}

function ocultarError(elementId) {
    const element = document.getElementById(elementId);
    element.style.display = 'none';
}

function mostrarNotificacion(mensaje, tipo) {
    const notificacion = document.createElement('div');
    notificacion.className = `notificacion ${tipo}`;
    notificacion.innerHTML = `
        <i class="fas fa-${tipo === 'success' ? 'check-circle' : 'exclamation-circle'}"></i>
        ${mensaje}
    `;
    document.body.appendChild(notificacion);
    
    setTimeout(() => {
        notificacion.classList.add('show');
    }, 100);
    
    setTimeout(() => {
        notificacion.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notificacion);
        }, 300);
    }, 3000);
}

// Funciones para el modal
function abrirModal(titulo, mensaje, callback) {
    document.getElementById('modalTitle').textContent = titulo;
    document.getElementById('modalMessage').textContent = mensaje;
    
    // Remover eventos anteriores
    modalConfirm.replaceWith(modalConfirm.cloneNode(true));
    const newConfirm = document.getElementById('modalConfirm');
    
    newConfirm.addEventListener('click', function() {
        callback();
    });
    
    confirmModal.classList.remove('hidden');
}

function cerrarModal() {
    confirmModal.classList.add('hidden');
}